Big Data Reading Assignment 1
Done By, 
Kausik N
COE17B010